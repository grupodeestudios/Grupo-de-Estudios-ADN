<?php

class LP_Meta_Box extends RW_Meta_Box {
	public function is_edit_screen( $screen = null ) {
		return true;
	}
}